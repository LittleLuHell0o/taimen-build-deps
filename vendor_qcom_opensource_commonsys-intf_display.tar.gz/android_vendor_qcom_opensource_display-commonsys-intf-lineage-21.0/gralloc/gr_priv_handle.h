/*
 * Copyright (c) 2011-2019, The Linux Foundation. All rights reserved.
 * Not a Contribution
 *
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
* Changes from Qualcomm Innovation Center are provided under the following license:
* Copyright (c) 2022-2024 Qualcomm Innovation Center, Inc. All rights reserved.
* SPDX-License-Identifier: BSD-3-Clause-Clear
*/

#ifndef __GR_PRIV_HANDLE_H__
#define __GR_PRIV_HANDLE_H__

#include <log/log.h>
#include <hardware/gralloc.h>
#include <hardware/gralloc1.h>
#ifdef __cplusplus
#include <cinttypes>
#endif
#include <fcntl.h>

#include <array>
#include <vector>

#define GRALLOC1_FUNCTION_PERFORM 0x00001000

#define DBG_HANDLE false

typedef gralloc1_error_t (*GRALLOC1_PFN_PERFORM)(gralloc1_device_t *device, int operation, ...);

#define PRIV_HANDLE_CONST(exp) static_cast<const private_handle_t *>(exp)

#pragma pack(push, 4)

#ifndef MULTI_VIEW_SUPPORT
#ifdef __cplusplus
struct private_handle_t : public native_handle_t {
#else
struct private_handle_t {
        native_handle_t nativeHandle;
#endif
  enum {
    PRIV_FLAGS_FRAMEBUFFER = 0x00000001,
    PRIV_FLAGS_USES_ION = 0x00000008,
    PRIV_FLAGS_NEEDS_FLUSH = 0x00000020,
    PRIV_FLAGS_INTERNAL_ONLY = 0x00000040,
    PRIV_FLAGS_NON_CPU_WRITER = 0x00000080,
    PRIV_FLAGS_CACHED = 0x00000200,
    PRIV_FLAGS_SECURE_BUFFER = 0x00000400,
    PRIV_FLAGS_EXTERNAL_ONLY = 0x00002000,
    PRIV_FLAGS_PROTECTED_BUFFER = 0x00004000,
    PRIV_FLAGS_VIDEO_ENCODER = 0x00010000,
    PRIV_FLAGS_CAMERA_WRITE = 0x00020000,
    PRIV_FLAGS_CAMERA_READ = 0x00040000,
    PRIV_FLAGS_HW_COMPOSER = 0x00080000,
    PRIV_FLAGS_HW_TEXTURE = 0x00100000,
    PRIV_FLAGS_ITU_R_601 = 0x00200000,     // Unused from display
    PRIV_FLAGS_ITU_R_601_FR = 0x00400000,  // Unused from display
    PRIV_FLAGS_ITU_R_709 = 0x00800000,     // Unused from display
    PRIV_FLAGS_SECURE_DISPLAY = 0x01000000,
    PRIV_FLAGS_TILE_RENDERED = 0x02000000,
    PRIV_FLAGS_CPU_RENDERED = 0x04000000,
    PRIV_FLAGS_UBWC_ALIGNED = 0x08000000,
    PRIV_FLAGS_DISP_CONSUMER = 0x10000000,
    PRIV_FLAGS_CLIENT_ALLOCATED = 0x20000000,  // Ion buffer allocated outside of gralloc
    PRIV_FLAGS_UBWC_ALIGNED_PI = 0x40000000,  // PI format
  };

  // file-descriptors dup'd over IPC
  int fd;
  int fd_metadata;

  // values sent over IPC
  int magic;
  int flags;
  int width;             // holds width of the actual buffer allocated
  int height;            // holds height of the  actual buffer allocated
  int unaligned_width;   // holds width client asked to allocate
  int unaligned_height;  // holds height client asked to allocate
  int format;
  int buffer_type;
  unsigned int layer_count;
  uint64_t id;
  uint64_t usage;

  unsigned int size;
  unsigned int offset;
  unsigned int offset_metadata;
  uint64_t base;
  uint64_t base_metadata;
  uint64_t gpuaddr;
#ifdef GRALLOC_HANDLE_HAS_RESERVED_SIZE
  unsigned int reserved_size;
#endif
#ifdef GRALLOC_HANDLE_HAS_CUSTOM_CONTENT_MD_RESERVED_SIZE
  unsigned int custom_content_md_reserved_size;
#endif
#ifdef __cplusplus
  static const int kNumFds = 2;
  static const int kMagic = 'gmsm';
#ifdef GRALLOC_HANDLE_HAS_UBWCP_FORMAT
  unsigned int linear_size;
  int ubwcp_format;
#endif

  static inline int NumInts() {
    return ((sizeof(private_handle_t) - sizeof(native_handle_t)) / sizeof(int)) - kNumFds;
  }

  private_handle_t(int fd, int meta_fd, int flags, int width, int height, int uw, int uh,
                   int format, int buf_type, unsigned int size, uint64_t usage = 0)
      : fd(fd),
        fd_metadata(meta_fd),
        magic(kMagic),
        flags(flags),
        width(width),
        height(height),
        unaligned_width(uw),
        unaligned_height(uh),
        format(format),
        buffer_type(buf_type),
        layer_count(1),
        id(0),
        usage(usage),
        size(size),
        offset(0),
        offset_metadata(0),
        base(0),
        base_metadata(0),
        gpuaddr(0)
#ifdef GRALLOC_HANDLE_HAS_RESERVED_SIZE
        ,reserved_size(0)
#endif
#ifdef GRALLOC_HANDLE_HAS_CUSTOM_CONTENT_MD_RESERVED_SIZE
        ,custom_content_md_reserved_size(0)
#endif
#ifdef GRALLOC_HANDLE_HAS_UBWCP_FORMAT
        ,linear_size(0)
        ,ubwcp_format(format)
#endif
  {
    version = static_cast<int>(sizeof(native_handle));
    numInts = NumInts();
    numFds = kNumFds;
  }

  // Legacy constructor used by some clients
  private_handle_t(int fd, unsigned int size, int usage, int buf_type, int format, int w, int h)
      : private_handle_t(fd, -1, PRIV_FLAGS_CLIENT_ALLOCATED, w, h, 0, 0, format, buf_type, size,
                         static_cast<uint64_t>(usage)) {}

  ~private_handle_t() {
    magic = 0;
    ALOGE_IF(DBG_HANDLE, "Deleting buffer handle %p", this);
  }

  static int validate(const native_handle *h) {
    auto *hnd = static_cast<const private_handle_t *>(h);
    if (!h || h->version != sizeof(native_handle) || h->numInts != NumInts() ||
        h->numFds != kNumFds) {
      ALOGE("Invalid gralloc handle (at %p): ver(%d/%zu) ints(%d/%d) fds(%d/%d)",
          h, h ? h->version : -1, sizeof(native_handle), h ? h->numInts : -1, NumInts(),
          h ? h->numFds : -1, kNumFds);
      return -EINVAL;
    }
    if (hnd->magic != kMagic) {
      ALOGE("handle = %p  invalid  magic(%c%c%c%c/%c%c%c%c)",hnd,
          hnd ? (((hnd->magic >> 24) & 0xFF) ? ((hnd->magic >> 24) & 0xFF) : '-') : '?',
          hnd ? (((hnd->magic >> 16) & 0xFF) ? ((hnd->magic >> 16) & 0xFF) : '-') : '?',
          hnd ? (((hnd->magic >> 8) & 0xFF) ? ((hnd->magic >> 8) & 0xFF) : '-') : '?',
          hnd ? (((hnd->magic >> 0) & 0xFF) ? ((hnd->magic >> 0) & 0xFF) : '-') : '?',
          (kMagic >> 24) & 0xFF, (kMagic >> 16) & 0xFF, (kMagic >> 8) & 0xFF, (kMagic >> 0) & 0xFF);
      return -EINVAL;
    }

    return 0;
  }

  static void Dump(const private_handle_t *hnd) {
    ALOGD("handle id:%" PRIu64
          " wxh:%dx%d uwxuh:%dx%d size: %d fd:%d fd_meta:%d flags:0x%x "
          "usage:0x%" PRIx64 "  format:0x%x layer_count: %d",
          hnd->id, hnd->width, hnd->height, hnd->unaligned_width, hnd->unaligned_height, hnd->size,
          hnd->fd, hnd->fd_metadata, hnd->flags, hnd->usage, hnd->format, hnd->layer_count);
  }

  int GetUnalignedWidth() const { return unaligned_width; }

  int GetUnalignedHeight() const { return unaligned_height; }

  int GetColorFormat() const { return format; }

  unsigned int GetLayerCount() const { return layer_count; }

  int GetStride() const {
    // In handle we currently store aligned width after allocation.
    return width;
  }

  uint64_t GetUsage() const { return usage; }

  uint64_t GetBackingstore() const { return id; }
#endif
};

#else

enum : uint32_t {
  PRIV_VIEW_MASK_PRIMARY = 0x00000001,
  PRIV_VIEW_MASK_SECONDARY = 0x00000002,
  PRIV_VIEW_MASK_PRIMARY_DEPTH = 0x00000004,
  PRIV_VIEW_MASK_SECONDARY_DEPTH = 0x00000008,
};

struct private_handle_t : public native_handle_t {
 protected:
  private_handle_t() {}
  struct FdPair;
  struct PvtHandleProperties;
  static const int kMagic = 'gmsm';
 public:
  enum {
    PRIV_FLAGS_FRAMEBUFFER = 0x00000001,
    PRIV_FLAGS_USES_ION = 0x00000008,
    PRIV_FLAGS_NEEDS_FLUSH = 0x00000020,
    PRIV_FLAGS_INTERNAL_ONLY = 0x00000040,
    PRIV_FLAGS_NON_CPU_WRITER = 0x00000080,
    PRIV_FLAGS_CACHED = 0x00000200,
    PRIV_FLAGS_SECURE_BUFFER = 0x00000400,
    PRIV_FLAGS_EXTERNAL_ONLY = 0x00002000,
    PRIV_FLAGS_PROTECTED_BUFFER = 0x00004000,
    PRIV_FLAGS_VIDEO_ENCODER = 0x00010000,
    PRIV_FLAGS_CAMERA_WRITE = 0x00020000,
    PRIV_FLAGS_CAMERA_READ = 0x00040000,
    PRIV_FLAGS_HW_COMPOSER = 0x00080000,
    PRIV_FLAGS_HW_TEXTURE = 0x00100000,
    PRIV_FLAGS_ITU_R_601 = 0x00200000,     // Unused from display
    PRIV_FLAGS_ITU_R_601_FR = 0x00400000,  // Unused from display
    PRIV_FLAGS_ITU_R_709 = 0x00800000,     // Unused from display
    PRIV_FLAGS_SECURE_DISPLAY = 0x01000000,
    PRIV_FLAGS_TILE_RENDERED = 0x02000000,
    PRIV_FLAGS_CPU_RENDERED = 0x04000000,
    PRIV_FLAGS_UBWC_ALIGNED = 0x08000000,
    PRIV_FLAGS_DISP_CONSUMER = 0x10000000,
    PRIV_FLAGS_CLIENT_ALLOCATED = 0x20000000,  // Ion buffer allocated outside of gralloc
    PRIV_FLAGS_UBWC_ALIGNED_PI = 0x40000000,  // PI format
  };
  // file-descriptors dup'd over IPC
  int& fd();
  int& fd_metadata();
  // values sent over IPC
  uint32_t& view();
  int& magic();
  int& flags();
  int& width();             // holds width of the actual buffer allocated
  int& height();            // holds height of the  actual buffer allocated
  int& unaligned_width();   // holds width client asked to allocate
  int& unaligned_height();  // holds height client asked to allocate
  int& format();
  int& buffer_type();
  unsigned int& layer_count();
  uint64_t& id();
  uint64_t& usage();
  unsigned int& size();
  unsigned int& offset();
  unsigned int& offset_metadata();
  uint64_t& base();
  uint64_t& base_metadata();
  uint64_t& gpuaddr();
  unsigned int& reserved_size();
  unsigned int& custom_content_md_reserved_size();
  unsigned int& linear_size();
  int& ubwcp_format();

  ~private_handle_t() {};
  static int validate(native_handle_t *h);
  static void Dump(private_handle_t *hnd);
  std::vector<FdPair> getFds();
  void closeFds();
  uint32_t getViewInfo();
  private_handle_t* CreateViewHandle(uint32_t view);

  static private_handle_t *createSingleHandle(
      int fd, int meta_fd, int flags, int width_in_bytes, int height, int uw,
      int uh, int format, int buf_type, uint64_t id1, unsigned int size,
      unsigned int reserved_size, unsigned int layer_count, uint64_t usage);

  static private_handle_t *createLRMetaHandle(
      int fd1, int meta_fd1, int fd2, int meta_fd2, int flags, int width_in_bytes,
      int height, int uw, int uh, int format, int buf_type, uint64_t id1, uint64_t id2,
      unsigned int size, unsigned int reserved_size, unsigned int layer_count, uint64_t usage);

 private:
  private_handle_t(const private_handle_t &other) = delete;
  private_handle_t &operator=(const private_handle_t &other) = delete;

  int getN();
  FdPair &currentFdPair();
  PvtHandleProperties &currentProperties();
};

struct private_handle_t::FdPair {
  int fd;
  int fd_metadata;
};

struct private_handle_t::PvtHandleProperties {
  uint32_t view;
  int magic;
  int flags;
  int width;             // holds width of the actual buffer allocated
  int height;            // holds height of the  actual buffer allocated
  int unaligned_width;   // holds width client asked to allocate
  int unaligned_height;  // holds height client asked to allocate
  int format;
  int buffer_type;
  unsigned int layer_count;
  uint64_t id;
  uint64_t usage;
  unsigned int size;
  unsigned int offset;
  unsigned int offset_metadata;
  uint64_t base;
  uint64_t base_metadata;
  uint64_t gpuaddr;
  unsigned int reserved_size;
  unsigned int custom_content_md_reserved_size;
  unsigned int linear_size;
  int ubwcp_format;
};

#define DEFINE_FD_ACCESSOR(cls, type, var) \
  inline type &cls::var() {                       \
    return currentFdPair().var;            \
  }

#define DEFINE_PROPERTY_ACCESSOR(cls, type, var) \
  inline type &cls::var() {                             \
    return currentProperties().var;              \
  }

DEFINE_FD_ACCESSOR(private_handle_t, int, fd)
DEFINE_FD_ACCESSOR(private_handle_t, int, fd_metadata)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, uint32_t, view)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, int, magic)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, int, flags)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, int, width)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, int, height)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, int, unaligned_width)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, int, unaligned_height)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, int, format)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, int, buffer_type)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, unsigned int, layer_count)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, uint64_t, id)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, uint64_t, usage)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, unsigned int, size)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, unsigned int, offset)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, unsigned int, offset_metadata)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, uint64_t, base)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, uint64_t, base_metadata)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, uint64_t, gpuaddr)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, unsigned int, reserved_size)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, unsigned int, custom_content_md_reserved_size)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, unsigned int, linear_size)
DEFINE_PROPERTY_ACCESSOR(private_handle_t, int, ubwcp_format)

template <int N>
struct PvtHandleData : public private_handle_t {
 public:
  std::array<FdPair, N> fdPairArray{};
  std::array<PvtHandleProperties, N> propertiesArray{};

  int getNumInts() { return sizeof(propertiesArray) / sizeof(int); }

  static int getNumInts(int n) { return sizeof(PvtHandleProperties) / sizeof(int) * n; }

  FdPair &getFdPair(int n) { return fdPairArray[n]; }

  PvtHandleProperties &getProperties(int n) { return propertiesArray[n]; }

  static int getExpectedNumFds() { return sizeof(std::array<FdPair, N>) / sizeof(int); }

  static int getExpectedNumInts() {
    return sizeof(std::array<PvtHandleProperties, N>) / sizeof(int);
  }

  void setProperties(PvtHandleProperties &prop, int flags, uint32_t view, int width,
                     int height, int uw, int uh, int format, int buf_type, uint64_t id,
                     unsigned int size, unsigned int reserved_size, unsigned int layer_count,
                     uint64_t usage = 0) {
    prop.magic = kMagic;
    prop.flags = flags;
    prop.width = width;
    prop.height = height;
    prop.unaligned_width = uw;
    prop.unaligned_height = uh;
    prop.format = format;
    prop.buffer_type = buf_type;
    prop.layer_count = layer_count;
    prop.id = id;
    prop.usage = usage;
    prop.size = size;
    prop.offset = 0;
    prop.offset_metadata = 0;
    prop.base = 0;
    prop.base_metadata = 0;
    prop.gpuaddr = 0;
    prop.reserved_size = reserved_size;
    prop.custom_content_md_reserved_size = 0;
    prop.linear_size = 0;
    prop.ubwcp_format = format;
    prop.view = view;
  }
};

inline int private_handle_t::getN() {
  return numFds / (sizeof(FdPair) / sizeof(int));
}

inline private_handle_t::FdPair &private_handle_t::currentFdPair() {
  switch (getN()) {
    case 1:
      return static_cast<PvtHandleData<1> *>(this)->getFdPair(0);
    case 2:
      return static_cast<PvtHandleData<2> *>(this)->getFdPair(0);
    default:
      // trespass
      ALOGE("Unsupported meta handle of N %d", getN());
      return static_cast<PvtHandleData<1> *>(this)->getFdPair(0);
  }
}

inline private_handle_t::PvtHandleProperties &private_handle_t::currentProperties() {
  switch (getN()) {
    case 1:
      return static_cast<PvtHandleData<1> *>(this)->getProperties(0);
    case 2:
      return static_cast<PvtHandleData<2> *>(this)->getProperties(0);
    default:
      // trespass
      ALOGE("Unsupported meta handle of N %d", getN());
      return static_cast<PvtHandleData<1> *>(this)->getProperties(0);
  }
}

inline void private_handle_t::closeFds() {
  std::vector<FdPair> fd_pairs = (this)->getFds();
  for (const auto &fd_pair : fd_pairs) {
    close(fd_pair.fd);
    close(fd_pair.fd_metadata);
  }
}

inline std::vector<private_handle_t::FdPair> private_handle_t::getFds() {
  //create vector,switch case, push on to vector
  std::vector<private_handle_t::FdPair> fd_pairs;
  switch (getN()) {
    case 1:
      fd_pairs.emplace_back(static_cast<PvtHandleData<1> *>(this)->getFdPair(0));
      break;
    case 2:
      fd_pairs.emplace_back(static_cast<PvtHandleData<2> *>(this)->getFdPair(0));
      fd_pairs.emplace_back(static_cast<PvtHandleData<2> *>(this)->getFdPair(1));
      break;
    default:
      ALOGE("Unsupported meta handle of N %d", getN());
      fd_pairs.emplace_back(static_cast<PvtHandleData<1> *>(this)->getFdPair(0));
      break;
  }
  return fd_pairs;
}

inline uint32_t private_handle_t::getViewInfo() {
    uint32_t viewInfo = 0;

    switch (getN()) {
      case 1:
        viewInfo = (this)->view();
        break;
      case 2:
        for (const auto& properties : static_cast<PvtHandleData<2>*>(this)->propertiesArray) {
          viewInfo |= properties.view;
        }
        break;
      default:
        ALOGE("Unsupported view info handle of N %d", getN());
        viewInfo = (this)->view();
        break;
    }
    return viewInfo;
}

inline int private_handle_t::validate(native_handle_t *h) {
  if (!h) {
    ALOGE("null native_handle_t");
    return -1;
  }

  private_handle_t *pvt = static_cast<private_handle_t *>(h);
  const int n = pvt->getN();

  if (n == 1) {
    if (pvt->numFds != PvtHandleData<1>::getExpectedNumFds() ||
        pvt->numInts != PvtHandleData<1>::getExpectedNumInts()) {
      ALOGE(
          "Invalid native_handle_t (at %p): ver(%d) N(%d) Expected ints: (%d) Actual ints:(%d) "
          "Expected fds: (%d) Actual fds:(%d) ",
          h, h->version, n, PvtHandleData<1>::getExpectedNumInts(), h->numInts,
          PvtHandleData<1>::getExpectedNumFds(), h->numFds);
      return -1;
    }
    if (pvt->magic() != kMagic) {
      ALOGE("handle = %p  invalid  magic(%c%c%c%c/%c%c%c%c)", pvt,
            pvt ? (((pvt->magic() >> 24) & 0xFF) ? ((pvt->magic() >> 24) & 0xFF) : '-') : '?',
            pvt ? (((pvt->magic() >> 16) & 0xFF) ? ((pvt->magic() >> 16) & 0xFF) : '-') : '?',
            pvt ? (((pvt->magic() >> 8) & 0xFF) ? ((pvt->magic() >> 8) & 0xFF) : '-') : '?',
            pvt ? (((pvt->magic() >> 0) & 0xFF) ? ((pvt->magic() >> 0) & 0xFF) : '-') : '?',
            (kMagic >> 24) & 0xFF, (kMagic >> 16) & 0xFF, (kMagic >> 8) & 0xFF,
            (kMagic >> 0) & 0xFF);
      return -1;
    }
  } else if (n == 2) {
    if (pvt->numFds != PvtHandleData<2>::getExpectedNumFds() ||
        pvt->numInts != PvtHandleData<2>::getExpectedNumInts()) {
      ALOGE(
          "Invalid native_handle_t (at %p): ver(%d) N(%d) Expected ints: (%d) Actual ints:(%d) "
          "Expected fds: (%d) Actual fds:(%d) ",
          h, h->version, n, PvtHandleData<2>::getExpectedNumInts(), h->numInts,
          PvtHandleData<2>::getExpectedNumFds(), h->numFds);
      return -1;
    }
    if (pvt->magic() != kMagic) {
      ALOGE("handle = %p  invalid  magic(%c%c%c%c/%c%c%c%c)", pvt,
            pvt ? (((pvt->magic() >> 24) & 0xFF) ? ((pvt->magic() >> 24) & 0xFF) : '-') : '?',
            pvt ? (((pvt->magic() >> 16) & 0xFF) ? ((pvt->magic() >> 16) & 0xFF) : '-') : '?',
            pvt ? (((pvt->magic() >> 8) & 0xFF) ? ((pvt->magic() >> 8) & 0xFF) : '-') : '?',
            pvt ? (((pvt->magic() >> 0) & 0xFF) ? ((pvt->magic() >> 0) & 0xFF) : '-') : '?',
            (kMagic >> 24) & 0xFF, (kMagic >> 16) & 0xFF, (kMagic >> 8) & 0xFF,
            (kMagic >> 0) & 0xFF);
      return -1;
    }
  } else {
    ALOGE("Invalid native_handle_t (at %p): ver(%d) N(%d) ints(%d) fds(%d)", h, h->version, n,
          h->numInts, h->numFds);
    return -1;
  }
  return 0;
}

inline private_handle_t *private_handle_t::createSingleHandle(
    int fd, int meta_fd, int flags, int width_in_bytes, int height, int uw,
    int uh, int format, int buf_type, uint64_t id, unsigned int size,
    unsigned int reserved_size, unsigned int layer_count, uint64_t usage) {
  size_t handle_size = sizeof(PvtHandleProperties) + sizeof(FdPair) + sizeof(native_handle_t);
  PvtHandleData<1> *h = static_cast<PvtHandleData<1> *>(malloc(handle_size));

  h->numInts = PvtHandleData<1>::getExpectedNumInts();
  h->numFds = PvtHandleData<1>::getExpectedNumFds();
  h->version = static_cast<int>(sizeof(native_handle_t));

  FdPair &fd_primary = h->getFdPair(0);
  fd_primary.fd = fd;
  fd_primary.fd_metadata = meta_fd;

  PvtHandleProperties &prop = h->getProperties(0);
  h->setProperties(prop, flags, PRIV_VIEW_MASK_PRIMARY, width_in_bytes, height, uw, uh,
                   format, buf_type, id, size, reserved_size, layer_count, usage);
  return h;
}

inline private_handle_t *private_handle_t::createLRMetaHandle(
    int fd1, int meta_fd1, int fd2, int meta_fd2, int flags, int width_in_bytes, int height,
    int uw, int uh, int format, int buf_type, uint64_t id1, uint64_t id2, unsigned int size,
    unsigned int reserved_size, unsigned int layer_count, uint64_t usage) {
  size_t handle_size =
      ((sizeof(PvtHandleProperties) + sizeof(FdPair)) * 2 + sizeof(native_handle_t));
  PvtHandleData<2> *h = static_cast<PvtHandleData<2> *>(malloc(handle_size));

  h->numInts = PvtHandleData<2>::getExpectedNumInts();
  h->numFds = PvtHandleData<2>::getExpectedNumFds();
  h->version = static_cast<int>(sizeof(native_handle_t));

  FdPair &fd_primary = h->getFdPair(0);
  fd_primary.fd = fd1;
  fd_primary.fd_metadata = meta_fd1;

  FdPair &fd_secondary = h->getFdPair(1);
  fd_secondary.fd = fd2;
  fd_secondary.fd_metadata = meta_fd2;

  PvtHandleProperties &prop_primary = h->getProperties(0);
  h->setProperties(prop_primary, flags, PRIV_VIEW_MASK_PRIMARY, width_in_bytes, height, uw, uh,
                   format, buf_type, id1, size, reserved_size, layer_count, usage);

  PvtHandleProperties &prop_secondary = h->getProperties(1);
  h->setProperties(prop_secondary, flags, PRIV_VIEW_MASK_SECONDARY, width_in_bytes, height,
                   uw, uh, format, buf_type, id2, size, reserved_size, layer_count, usage);

  return h;
}

inline void private_handle_t::Dump(private_handle_t *hnd) {
  ALOGD("handle id:%" PRIu64
        " wxh:%dx%d uwxuh:%dx%d size: %d fd:%d fd_meta:%d flags:0x%x "
        "usage:0x%" PRIx64 "  format:0x%x layer_count: %d reserved_size = %d "
        "custom_content_md_reserved_size = %u",
        hnd->id(), hnd->width(), hnd->height(), hnd->unaligned_width(), hnd->unaligned_height(),
        hnd->size(), hnd->fd(), hnd->fd_metadata(), hnd->flags(), hnd->usage(), hnd->format(),
        hnd->layer_count(), hnd->reserved_size(), hnd->custom_content_md_reserved_size());
}

inline private_handle_t* private_handle_t::CreateViewHandle(uint32_t view) {
  int N = getN();

  if (N > 2) {
    ALOGE("Unsupported meta handle of N %d", N);
    return nullptr;
  }

  int view_index = -1;
  switch (view) {
    case PRIV_VIEW_MASK_PRIMARY:
      view_index = 0;
      break;
    case PRIV_VIEW_MASK_SECONDARY:
      view_index = 1;
      break;
    default:
      ALOGE("Unsupported view mask %d", view);
      return nullptr;
  }

  if (view_index >= N) {
    ALOGE("Meta Handle doesn't contain the requested view %d", view);
    return nullptr;
  }

  size_t handle_size = sizeof(PvtHandleProperties) + sizeof(FdPair) + sizeof(native_handle_t);
  PvtHandleData<1> *view_handle = static_cast<PvtHandleData<1> *>(malloc(handle_size));

  view_handle->numInts = PvtHandleData<1>::getExpectedNumInts();
  view_handle->numFds = PvtHandleData<1>::getExpectedNumFds();
  view_handle->version  = static_cast<int>(sizeof(native_handle_t));

  switch (N) {
    case 2:
      view_handle->getFdPair(0).fd =
          fcntl(static_cast<PvtHandleData<2>*>(this)->getFdPair(view_index).fd,
                F_DUPFD_CLOEXEC, 0);
      view_handle->getFdPair(0).fd_metadata =
          fcntl(static_cast<PvtHandleData<2>*>(this)->getFdPair(view_index).fd_metadata,
                F_DUPFD_CLOEXEC, 0);
      view_handle->getProperties(0) =
          static_cast<PvtHandleData<2>*>(this)->getProperties(view_index);
      break;
    default:
      ALOGE("Unsupported Meta Handle");
      free(view_handle);
      return nullptr;
  }

  return static_cast<private_handle_t*>(view_handle);
}

#endif  // MULTI_VIEW_SUPPORT

#pragma pack(pop)

#endif  // __GR_PRIV_HANDLE_H__
