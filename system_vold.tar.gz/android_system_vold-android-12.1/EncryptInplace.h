/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _ENCRYPT_INPLACE_H
#define _ENCRYPT_INPLACE_H

#include <stdint.h>
#include <string>

bool encrypt_inplace(const std::string& crypto_blkdev, const std::string& real_blkdev,
                     uint64_t nr_sec, bool set_progress_properties);

#endif
